//ADT Map � using a DLLA with (key, value) pairs

#include <iostream>
#include "ShortTest.h"
#include "ExtendedTest.h"

int main()
{
	//testAll();
	testAllExtended();
	return 0;
}